# Pres_Election_2020
Analysis of election results in Lake County, IL

To download six interactive maps showing 2020 Lake County general election results for the offices 
of U.S. President and U.S. Representative for the 6th, 10th, and 14th congressional districts: 

-- Click on the green button labeled "Code"

-- Click on "Download ZIP"

-- Select the folder on your device where the ZIP file will be stored

-- Right click on the ZIP file and select "Extract All"

-- Click on the button labeled "Extract"

-- Double click on the folder entitled "Pres_Election_2020-public_download"

-- You should now see the six interactive map files with html extensions. Double clicking on 
any of them will open the interactive map in your browser window.

-- Have fun exploring!
